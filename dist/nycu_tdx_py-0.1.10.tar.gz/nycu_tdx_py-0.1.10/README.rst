
Example Project
===============
This is package is used to connect data from Transport Data eXchange via Python.

Installing
============

.. code-block:: bash

    pip install nycu-tdx-py